exports.id=105,exports.ids=[105],exports.modules={7495:e=>{function t(e){var t=Error("Cannot find module '"+e+"'");throw t.code="MODULE_NOT_FOUND",t}t.keys=()=>[],t.resolve=t,t.id=7495,e.exports=t},8359:()=>{},3739:()=>{},930:(e,t,n)=>{"use strict";n.d(t,{m:()=>o});var s=n(5673),a=n(7277),i=n(1210);class r extends s.EventEmitter{constructor(){super(),this.runningScans=new Map,this.broadcaster=i.U.getInstance(),console.log("Docker Manager initialized in serverless/simulation mode")}async executeScan(e,t,n,s){try{return console.log(`Starting simulated scan ${e} for user ${n}`),this.simulateExecution(e,t,n,s)}catch(t){return console.error(`Failed to execute scan ${e}:`,t),await (0,a.BL)(e,n,"error",t.message),{success:!1,error:t.message}}}async simulateExecution(e,t,n,s){console.log(`Simulating scan execution for ${e}: ${t}`);try{let i=`sim-${e}-${Date.now()}`,r={containerId:i,startTime:new Date,killed:!1};this.runningScans.set(e,r),await (0,a.w1)(e,"running"),await (0,a.BL)(e,n,"info",`Starting simulated scan: ${t}`),this.broadcaster.broadcastScanProgress(e,n,{scanId:e,status:"running",progress:10,currentStep:"Initializing security scan container...",output:`Command: ${t}`}),await this.simulateProgressiveExecution(e,n,t,s);let o=this.generateSimulatedOutput(t,s);return await (0,a.BL)(e,n,"info",o),await (0,a.w1)(e,"completed"),this.broadcaster.broadcastScanComplete(e,n,{exitCode:0,message:"Scan completed successfully",output:o}),this.runningScans.delete(e),{success:!0,output:o,containerId:i}}catch(t){return await (0,a.w1)(e,"failed"),await (0,a.BL)(e,n,"error",t.message),this.broadcaster.broadcastScanError(e,n,{exitCode:1,message:t.message}),{success:!1,error:t.message}}}async simulateProgressiveExecution(e,t,n,s){for(let{progress:n,step:s,delay:a}of[{progress:20,step:"Preparing security tools...",delay:1e3},{progress:35,step:"Scanning target infrastructure...",delay:1500},{progress:50,step:"Analyzing discovered services...",delay:2e3},{progress:70,step:"Testing for vulnerabilities...",delay:1800},{progress:85,step:"Generating security report...",delay:1200},{progress:100,step:"Scan completed successfully",delay:500}]){let i=this.runningScans.get(e);if(!i||i.killed)break;this.broadcaster.broadcastScanProgress(e,t,{scanId:e,status:"running",progress:n,currentStep:s,output:`[${new Date().toLocaleTimeString()}] ${s}`}),await new Promise(e=>setTimeout(e,a))}}generateSimulatedOutput(e,t){let n=new Date().toISOString(),s=t||"target-system",a=e.toLowerCase();return a.includes("nmap")?`# Nmap Scan Results
## Target: ${s}
## Scan Time: ${n}

Starting Nmap 7.94 ( https://nmap.org )
Nmap scan report for ${s}
Host is up (0.045s latency).

PORT     STATE SERVICE VERSION
22/tcp   open  ssh     OpenSSH 8.2p1 Ubuntu 4ubuntu0.5
80/tcp   open  http    Apache httpd 2.4.41 ((Ubuntu))
443/tcp  open  https   Apache httpd 2.4.41 ((Ubuntu))
3306/tcp open  mysql   MySQL 8.0.32-0ubuntu0.20.04.2

Service Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel

Service detection performed. Please report any incorrect results.
Nmap done: 1 IP address (1 host up) scanned in 12.48 seconds

## Security Notes:
- SSH service detected on standard port 22
- Web services running on ports 80 and 443
- MySQL database exposed on port 3306
- Recommend firewall review for database exposure`:a.includes("nikto")?`# Nikto Web Vulnerability Scan
## Target: ${s}
## Scan Time: ${n}

- Nikto v2.5.0
+ Target IP:          ${s}
+ Target Hostname:    ${s}
+ Target Port:        80
+ Start Time:         ${new Date().toLocaleTimeString()}

+ Server: Apache/2.4.41 (Ubuntu)
+ Server may leak inodes via ETags
+ The anti-clickjacking X-Frame-Options header is not present.
+ The X-XSS-Protection header is not defined.
+ The X-Content-Type-Options header is not set.
+ Uncommon header 'x-powered-by' found, with contents: PHP/7.4.3
+ Apache/2.4.41 appears to be outdated (current is at least Apache/2.4.54).
+ /admin/: Admin directory found (may need authentication)
+ /config/: Directory indexing found.
+ /icons/README: Apache default file found.
+ /.htaccess: .htaccess file is readable. See RFC 3875
+ /phpmyadmin/: phpMyAdmin directory found

## Findings Summary:
+ 8734 requests: 0 error(s) and 11 item(s) reported
+ End Time: ${new Date().toLocaleTimeString()} (estimated 35 seconds)

## Recommendations:
- Update Apache to latest version
- Configure security headers
- Restrict admin directory access
- Remove default Apache files`:a.includes("sqlmap")?`# SQLMap Injection Analysis
## Target: ${s}
## Scan Time: ${n}

sqlmap/1.7.2#stable (http://sqlmap.org)

[${new Date().toLocaleTimeString()}] [INFO] starting
[${new Date().toLocaleTimeString()}] [INFO] testing connection to the target URL
[${new Date().toLocaleTimeString()}] [INFO] checking if the target is protected
[${new Date().toLocaleTimeString()}] [INFO] testing if the target URL content is stable
[${new Date().toLocaleTimeString()}] [INFO] target URL content is stable
[${new Date().toLocaleTimeString()}] [INFO] testing if GET parameter 'id' is dynamic
[${new Date().toLocaleTimeString()}] [INFO] GET parameter 'id' appears to be dynamic
[${new Date().toLocaleTimeString()}] [INFO] heuristic (basic) test shows that GET parameter 'id' might be injectable
[${new Date().toLocaleTimeString()}] [INFO] testing for SQL injection on GET parameter 'id'

## Injection Point Found:
Parameter: id (GET)
    Type: boolean-based blind
    Title: AND boolean-based blind - WHERE or HAVING clause
    Payload: id=1 AND 1234=1234

    Type: time-based blind
    Title: MySQL >= 5.0.12 AND time-based blind (query SLEEP)
    Payload: id=1 AND (SELECT 1234 FROM (SELECT(SLEEP(5)))abc)

## Target Analysis:
web server operating system: Linux Ubuntu 20.04
web application technology: Apache 2.4.41, PHP 7.4.3
back-end DBMS: MySQL >= 5.0.12

## Security Risk: HIGH
- SQL injection vulnerability confirmed
- Database information disclosure possible
- Recommend immediate patching`:a.includes("gobuster")||a.includes("dirb")?`# Directory Brute Force Scan
## Target: ${s}
## Scan Time: ${n}

Gobuster v3.6
by OJ Reeves (@TheColonial) & Christian Mehlmauer (@firefart)

[+] Url:                     http://${s}
[+] Method:                  GET
[+] Threads:                 10
[+] Wordlist:                /usr/share/wordlists/dirb/common.txt
[+] Status codes:            200,204,301,302,307,401,403,405

## Discovered Directories and Files:
/.htaccess            (Status: 403) [Size: 278]
/.htpasswd            (Status: 403) [Size: 278]
/admin                (Status: 301) [Size: 312] [--> http://${s}/admin/]
/backup               (Status: 301) [Size: 313] [--> http://${s}/backup/]
/config               (Status: 301) [Size: 313] [--> http://${s}/config/]
/css                  (Status: 301) [Size: 310] [--> http://${s}/css/]
/images               (Status: 301) [Size: 313] [--> http://${s}/images/]
/js                   (Status: 301) [Size: 309] [--> http://${s}/js/]
/phpmyadmin           (Status: 301) [Size: 317] [--> http://${s}/phpmyadmin/]
/uploads              (Status: 301) [Size: 314] [--> http://${s}/uploads/]

## Security Findings:
- Admin panel discovered at /admin
- Backup directory found (potential data exposure)
- Database management interface accessible
- File upload directory identified`:`# Comprehensive Security Scan Results
## Target: ${s}
## Command: ${e}
## Scan Time: ${n}

## Executive Summary:
Security assessment completed for ${s}. Multiple security findings identified across different categories.

## Findings Overview:
🔴 HIGH RISK:     2 findings
🟡 MEDIUM RISK:   3 findings
🟢 LOW RISK:      1 finding

## Detailed Findings:

### 1. Outdated Software Components [HIGH]
- Apache 2.4.41 (Current: 2.4.54+)
- PHP 7.4.3 (End of life)
- MySQL 8.0.32 (Security updates available)

### 2. Missing Security Headers [MEDIUM]
- X-Frame-Options not set
- X-Content-Type-Options not configured
- X-XSS-Protection disabled

### 3. Directory Indexing Enabled [MEDIUM]
- /config/ directory browsable
- /backup/ directory accessible
- Potential information disclosure

### 4. Default Files Present [LOW]
- Apache default files detected
- README files in web root

## Recommendations:
1. Update all software components immediately
2. Configure security headers
3. Disable directory indexing
4. Remove default/sample files
5. Implement web application firewall
6. Regular security monitoring

## Compliance Impact:
- PCI DSS: Non-compliant (outdated software)
- OWASP Top 10: Multiple issues identified
- ISO 27001: Security controls needed

Scan completed at ${new Date().toLocaleTimeString()}`}async killScan(e){let t=this.runningScans.get(e);if(!t)return!1;try{return t.killed=!0,t.timeout&&clearTimeout(t.timeout),await (0,a.w1)(e,"cancelled"),this.runningScans.delete(e),console.log(`Killed simulated scan ${e}`),!0}catch(t){return console.error(`Failed to kill scan ${e}:`,t),!1}}async getContainerStatus(e){if(e){let t=this.runningScans.get(e);if(t)return{exists:!0,running:!t.killed,stats:{memory_usage:"128MB",cpu_usage:"15%",uptime:`${Math.floor((Date.now()-t.startTime.getTime())/1e3)}s`,container_id:t.containerId,image:"pentriarch/security-scanner:latest",created:t.startTime.toISOString()}}}return{exists:!1,running:!1}}async cleanup(){for(let[e]of(console.log("Cleaning up Docker manager..."),this.runningScans))await this.killScan(e);this.runningScans.clear()}async healthCheck(){return{docker:!1,image:!0,containers:this.runningScans.size}}async executeCommand(e,t,n){let s=Date.now();try{let a=await this.executeScan(t,e.toString(),"system"),i=Date.now()-s;return n&&a.output&&n(a.output),{success:a.success,output:a.output||"",duration:i,error:a.error}}catch(e){return{success:!1,output:"",duration:Date.now()-s,error:e.message}}}}let o=new r;"undefined"!=typeof process&&(process.on("SIGINT",async()=>{console.log("Received SIGINT, cleaning up..."),await o.cleanup(),process.exit(0)}),process.on("SIGTERM",async()=>{console.log("Received SIGTERM, cleaning up..."),await o.cleanup(),process.exit(0)}))},7277:(e,t,n)=>{"use strict";n.d(t,{sc:()=>S,ts:()=>o,T_:()=>p,getScanById:()=>d,getScanLogs:()=>g,gG:()=>h,n_:()=>u,Z0:()=>c,wy:()=>m,BL:()=>y,Go:()=>w,supabase:()=>a,w1:()=>l});var s=n(785);n(7721),n(6751);let a=(0,s.createClient)("https://povfmblwwtxqemqgomge.supabase.co","eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBvdmZtYmx3d3R4cWVtcWdvbWdlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTAzMjM3OTMsImV4cCI6MjA2NTg5OTc5M30.rdS3b08AQxEQOuJ_An5x4MnOCYAMSMF4kNyyVuY3df4"),i=()=>({id:"demo-user-123",email:"demo@pentriarch.ai",name:"Demo User",created_at:new Date().toISOString(),role:"user"}),r=()=>[{id:"scan-1",user_id:"demo-user-123",target:"example.com",prompt:"Scan for common vulnerabilities",status:"completed",ai_model:"gpt-4",tool_used:"nmap",command_executed:"nmap -sV example.com",start_time:new Date(Date.now()-3e5).toISOString(),end_time:new Date(Date.now()-24e4).toISOString(),created_at:new Date(Date.now()-3e5).toISOString(),updated_at:new Date(Date.now()-24e4).toISOString(),metadata:{risk_assessment:"low"}},{id:"scan-2",user_id:"demo-user-123",target:"testsite.com",prompt:"Check for SQL injection vulnerabilities",status:"running",ai_model:"claude-3-sonnet",tool_used:"sqlmap",command_executed:"sqlmap -u testsite.com --batch",start_time:new Date(Date.now()-12e4).toISOString(),created_at:new Date(Date.now()-12e4).toISOString(),updated_at:new Date(Date.now()-6e4).toISOString(),metadata:{risk_assessment:"high"}}],o=async()=>{try{let{data:{user:e}}=await a.auth.getUser();return e}catch(e){return console.warn("Supabase auth error (demo mode available):",e),i()}},c=async e=>{try{let{data:t,error:n}=await a.from("scans").insert([e]).select().single();if(n)throw n;return t}catch(t){return console.warn("Supabase insert error, using demo data:",t),{...e,id:`demo-scan-${Date.now()}`,created_at:new Date().toISOString(),updated_at:new Date().toISOString()}}},l=async(e,t,n)=>{try{let s={status:t,updated_at:new Date().toISOString()};("completed"===t||"failed"===t)&&(s.end_time=new Date().toISOString()),n&&(s.metadata=n);let{data:i,error:r}=await a.from("scans").update(s).eq("id",e).select().single();if(r)throw r;return i}catch(n){return console.warn("Supabase update error, using demo response:",n),{id:e,status:t,updated_at:new Date().toISOString()}}},d=async e=>{try{let{data:t,error:n}=await a.from("scans").select("*").eq("id",e).single();if(n)throw n;return t}catch(e){return console.warn("Supabase query error, using demo data:",e),r()[0]}},u=async e=>{try{let{data:t,error:n}=await a.from("reports").insert([{...e,generated_at:new Date().toISOString()}]).select().single();if(n)throw n;return t}catch(t){return console.warn("Supabase insert error, using demo response:",t),{...e,id:`demo-report-${Date.now()}`,generated_at:new Date().toISOString()}}},p=async e=>{try{let{data:t,error:n}=await a.from("reports").select("*").eq("scan_id",e).single();if(n)throw n;return t}catch(t){return console.warn("Supabase query error, using demo data:",t),{id:"demo-report-1",scan_id:e,findings:[],summary:"Demo scan completed successfully",risk_score:3,generated_at:new Date().toISOString()}}},m=async e=>{try{let{data:t,error:n}=await a.from("scan_logs").insert([e]).select().single();if(n)throw n;return t}catch(t){return console.warn("Supabase insert error, using demo response:",t),{...e,id:`demo-log-${Date.now()}`}}},g=async e=>{try{let{data:t,error:n}=await a.from("scan_logs").select("*").eq("scan_id",e).order("timestamp",{ascending:!0});if(n)throw n;return t}catch(t){return console.warn("Supabase query error, using demo data:",t),[{id:"demo-log-1",scan_id:e,timestamp:new Date().toISOString(),level:"info",message:"Demo scan completed",raw_output:"Demo output for development"}]}},S=async e=>{try{let{data:t,error:n}=await a.from("notifications").insert([{...e,created_at:new Date().toISOString()}]).select().single();if(n)throw n;return t}catch(t){return console.warn("Supabase insert error, using demo response:",t),{...e,id:`demo-notification-${Date.now()}`,created_at:new Date().toISOString()}}},h=async e=>{try{let{data:t,error:n}=await a.from("notifications").select("*").eq("user_id",e).order("created_at",{ascending:!1});if(n)throw n;return t}catch(e){return console.warn("Supabase query error, using demo data:",e),[]}},w=async e=>{try{let{data:t,error:n}=await a.from("notifications").update({read:!0}).eq("id",e).select().single();if(n)throw n;return t}catch(t){return console.warn("Supabase update error, using demo response:",t),{id:e,read:!0}}},y=async(e,t,n,s,a)=>m({scan_id:e,timestamp:new Date().toISOString(),level:n,message:s,raw_output:a})},1210:(e,t,n)=>{"use strict";n.d(t,{U:()=>i});class s{on(e,t){this.events.has(e)||this.events.set(e,[]),this.events.get(e).push(t)}off(e,t){let n=this.events.get(e);if(n){let e=n.indexOf(t);-1!==e&&n.splice(e,1)}}emit(e,...t){let n=this.events.get(e);n&&n.forEach(e=>e(...t))}removeAllListeners(e){e?this.events.delete(e):this.events.clear()}constructor(){this.events=new Map}}class a extends s{constructor(){super(),this.connections=new Map,this.userConnections=new Map,this.heartbeatInterval=null,this.reconnectAttempts=new Map,this.pollingIntervals=new Map,this.maxReconnectAttempts=5,this.reconnectDelay=1e3,this.isWebSocketSupported=!0,this.startHeartbeat()}connect(e,t){if(!this.isWebSocketSupported)return console.log("WebSocket not supported, using polling fallback"),this.startPolling(e,t),null;try{let n=`${"https:"===window.location.protocol?"wss:":"ws:"}//${window.location.host}/api/ws`,s=new WebSocket(n);return s.onopen=()=>{console.log("WebSocket connected"),this.connections.set(e,s);try{s.send(JSON.stringify({type:"register",userId:e,timestamp:new Date().toISOString()}))}catch(e){console.error("Failed to register WebSocket user:",e)}this.reconnectAttempts.set(e,0),this.emit("connected",e)},s.onmessage=e=>{try{let n=JSON.parse(e.data);this.emit("message",n),t&&t(n)}catch(e){console.error("Failed to parse WebSocket message:",e),this.emit("error",{message:"Invalid message format"})}},s.onclose=n=>{console.log("WebSocket closed:",n.code,n.reason),this.connections.delete(e),this.emit("disconnected",e),1e3!==n.code&&1001!==n.code&&this.handleReconnect(e,t)},s.onerror=n=>{console.error("WebSocket error:",n),this.emit("error",n),0===this.reconnectAttempts.get(e)&&(console.log("WebSocket failed, falling back to polling"),this.isWebSocketSupported=!1,this.startPolling(e,t))},s}catch(n){return console.error("Failed to create WebSocket:",n),this.isWebSocketSupported=!1,this.startPolling(e,t),null}}startPolling(e,t){this.stopPolling(e),setTimeout(()=>{this.emit("connected",e)},100);let n=setInterval(async()=>{try{let n=await fetch("/api/status");if(n.ok){let s=await n.json();if(s.activeScans&&s.activeScans.length>0)for(let n of s.activeScans){let s={type:"scan_progress",scanId:n.id,userId:e,data:{scanId:n.id,status:n.status,progress:n.progress||0,currentStep:n.current_step||"Running...",output:n.latest_output},timestamp:new Date().toISOString()};t&&t(s),this.emit("message",s)}}}catch(e){console.debug("Polling error:",e)}},2e3);this.pollingIntervals.set(e,n)}stopPolling(e){let t=this.pollingIntervals.get(e);t&&(clearInterval(t),this.pollingIntervals.delete(e))}handleReconnect(e,t){let n=this.reconnectAttempts.get(e)||0;if(n>=this.maxReconnectAttempts){console.log("Max reconnection attempts reached for user",e),this.emit("reconnect_failed",e),this.isWebSocketSupported=!1,this.startPolling(e,t);return}let s=Math.min(this.reconnectDelay*2**n,3e4);this.reconnectAttempts.set(e,n+1),setTimeout(()=>{console.log(`Attempting to reconnect (${n+1}/${this.maxReconnectAttempts})`),this.connect(e,t)},s)}disconnect(e){this.stopPolling(e);let t=this.connections.get(e);return t&&t.readyState===WebSocket.OPEN?(t.close(1e3,"Client disconnect"),this.connections.delete(e),!0):(this.emit("disconnected",e),!1)}sendMessage(e,t){let n=this.connections.get(e);return!!n&&n.readyState===WebSocket.OPEN&&(n.send(JSON.stringify({...t,timestamp:new Date().toISOString()})),!0)}subscribeScan(e,t){return this.sendMessage(e,{type:"scan_progress",scanId:t,data:{action:"subscribe"}})}unsubscribeScan(e,t){return this.sendMessage(e,{type:"scan_progress",scanId:t,data:{action:"unsubscribe"}})}subscribeContainer(e,t){return this.sendMessage(e,{type:"container_status",scanId:t,data:{action:"subscribe"}})}subscribeNotifications(e){return this.sendMessage(e,{type:"notification",data:{action:"subscribe"}})}isConnected(e){let t=this.connections.get(e);return t?.readyState===WebSocket.OPEN}getConnectedUsers(){return Array.from(this.connections.keys()).filter(e=>this.isConnected(e))}startHeartbeat(){this.heartbeatInterval=setInterval(()=>{this.connections.forEach((e,t)=>{e.readyState===WebSocket.OPEN&&e.send(JSON.stringify({type:"ping",timestamp:new Date().toISOString()}))})},3e4)}destroy(){this.heartbeatInterval&&clearInterval(this.heartbeatInterval),this.connections.forEach((e,t)=>{this.disconnect(t)}),this.connections.clear(),this.userConnections.clear(),this.reconnectAttempts.clear()}}class i{static getInstance(){return i.instance||(i.instance=new i),i.instance}addConnection(e,t,n){this.connections.set(e,n),this.userConnections.has(t)||this.userConnections.set(t,new Set),this.userConnections.get(t)?.add(e)}removeConnection(e,t){this.connections.delete(e),this.userConnections.get(t)?.delete(e),this.userConnections.get(t)?.size===0&&this.userConnections.delete(t)}broadcastToUser(e,t){let n=this.userConnections.get(e);if(n)for(let e of n){let n=this.connections.get(e);n&&1===n.readyState&&n.send(JSON.stringify(t))}}broadcastToUsers(e,t){for(let n of e)this.broadcastToUser(n,t)}broadcastToAll(e){for(let t of this.connections.values())1===t.readyState&&t.send(JSON.stringify(e))}broadcastScanProgress(e,t,n){this.broadcastToUser(t,{type:"scan_progress",scanId:e,userId:t,data:n,timestamp:new Date().toISOString()})}broadcastContainerStatus(e,t,n){this.broadcastToUser(t,{type:"container_status",scanId:e,userId:t,data:n,timestamp:new Date().toISOString()})}broadcastNotification(e,t){this.broadcastToUser(e,{type:"notification",userId:e,data:t,timestamp:new Date().toISOString()})}broadcastScanComplete(e,t,n){this.broadcastToUser(t,{type:"scan_complete",scanId:e,userId:t,data:n,timestamp:new Date().toISOString()})}broadcastScanError(e,t,n){this.broadcastToUser(t,{type:"scan_error",scanId:e,userId:t,data:n,timestamp:new Date().toISOString()})}constructor(){this.connections=new Map,this.userConnections=new Map}}new a},6751:(e,t,n)=>{"use strict";n.d(t,{e:()=>a});var s=n(7721);let a=()=>{let e="https://povfmblwwtxqemqgomge.supabase.co",t="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBvdmZtYmx3d3R4cWVtcWdvbWdlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTAzMjM3OTMsImV4cCI6MjA2NTg5OTc5M30.rdS3b08AQxEQOuJ_An5x4MnOCYAMSMF4kNyyVuY3df4";if(!e||!t)throw Error("Missing Supabase environment variables");return(0,s.createServerClient)(e,t,{cookies:{getAll:()=>[],setAll(e){}}})}}};