(()=>{var e={};e.id=803,e.ids=[803],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},11997:e=>{"use strict";e.exports=require("punycode")},23007:(e,t,i)=>{"use strict";i.r(t),i.d(t,{patchFetch:()=>S,routeModule:()=>m,serverHooks:()=>h,workAsyncStorage:()=>g,workUnitAsyncStorage:()=>y});var s={};i.r(s),i.d(s,{GET:()=>p,POST:()=>u});var a=i(96559),n=i(48088),r=i(37719),o=i(32190),c=i(56621);class l{async analyzeVulnerabilities(e,t,i){try{let s=await this.analyzeContext(t,i),a=await this.performMultiStepReasoning(e,s),n=await this.calculateAdvancedRiskScore(e,t,a),r=await this.correlateFindingsWithAI(e,a),o=await this.generateIntelligentRemediation(e,n,t),c=await this.generatePredictiveInsights(e,t,i),l=await this.assessComplianceImpact(e,t);return{riskScore:n.totalScore,confidenceLevel:a.confidence,threatLevel:this.calculateThreatLevel(n.totalScore),reasoning:a.steps,correlatedFindings:r,remediationPlan:o,predictiveInsights:c,complianceImpact:l}}catch(e){throw console.error("AI Analysis Engine error:",e),Error(`AI analysis failed: ${e.message}`)}}async performMultiStepReasoning(e,t){let i=`
    As a senior penetration testing expert, perform multi-step reasoning analysis:

    FINDINGS:
    ${e.map(e=>`- ${e.title}: ${e.description} [${e.severity}]`).join("\n")}

    CONTEXT: ${JSON.stringify(t)}

    Perform step-by-step analysis:
    1. Attack Vector Analysis: How could these vulnerabilities be chained?
    2. Business Impact Assessment: What are the potential business consequences?
    3. Environmental Factors: How does the environment affect exploitability?
    4. Threat Actor Perspective: What would an attacker target first?
    5. Defense Evasion: What security controls could be bypassed?

    Provide reasoning steps and confidence level (0-100).
    `;try{let e=await this.callAIModel(this.AI_MODELS.reasoning,i);return this.parseReasoningResponse(e)}catch(e){return{steps:["Basic analysis performed due to AI service unavailability"],confidence:60}}}async calculateAdvancedRiskScore(e,t,i){let s=`
    Calculate advanced risk score considering:

    VULNERABILITIES: ${JSON.stringify(e.map(e=>({title:e.title,severity:e.severity,cve:e.cve_refs})))}

    CONTEXT: Business Critical: ${t.businessCritical}, Environment: ${t.environment}, Exposure: ${t.exposureLevel}

    REASONING: ${i.steps.join(" ")}

    Provide risk factors (0-100 each):
    - Severity: Base vulnerability severity
    - Exploitability: Ease of exploitation
    - Business Impact: Potential business damage
    - Data Exposure: Risk of data breach
    - Compliance: Regulatory impact
    - Patch Availability: How quickly can this be fixed

    Return JSON with risk factors and total weighted score.
    `;try{let e=await this.callAIModel(this.AI_MODELS.risk_assessment,s);return this.parseRiskResponse(e)}catch(i){return this.calculateFallbackRiskScore(e,t)}}async correlateFindingsWithAI(e,t){if(e.length<2)return e;let i=`
    Analyze vulnerability correlations for attack chain identification:

    FINDINGS: ${JSON.stringify(e)}
    REASONING: ${t.steps.join(" ")}

    Identify:
    1. Which vulnerabilities can be chained together?
    2. What would be the most effective attack path?
    3. Which findings amplify others' impact?
    4. Are there logical groupings by system/service?

    Return findings in order of attack chain priority.
    `;try{let t=await this.callAIModel(this.AI_MODELS.reasoning,i);return this.parseCorrelationResponse(t,e)}catch(t){return this.performBasicCorrelation(e)}}async generateIntelligentRemediation(e,t,i){let s=`
    Generate intelligent remediation plan for:

    VULNERABILITIES: ${JSON.stringify(e)}
    RISK SCORE: ${t.totalScore}
    CONTEXT: ${JSON.stringify(i)}

    For each vulnerability, provide:
    1. Priority level (immediate/high/medium/low)
    2. Specific action steps
    3. Estimated time to fix
    4. Risk reduction percentage
    5. Dependencies between fixes

    Consider:
    - Business continuity during fixes
    - Resource requirements
    - Optimal fix sequencing
    - Temporary mitigations

    Return structured remediation plan.
    `;try{let e=await this.callAIModel(this.AI_MODELS.remediation,s);return this.parseRemediationResponse(e)}catch(t){return this.generateBasicRemediation(e)}}async generatePredictiveInsights(e,t,i){let s=`
    Based on current findings, predict additional vulnerabilities:

    CURRENT FINDINGS: ${JSON.stringify(e)}
    SCAN LOGS: ${i.slice(-10).join("\n")}
    TARGET: ${t.target}

    Predict:
    1. Likely additional vulnerabilities based on patterns
    2. Services that should be investigated further
    3. Configuration issues that commonly co-occur
    4. Missing security controls based on what was found
    5. Recommended additional scans/tools

    Provide actionable predictions.
    `;try{let e=await this.callAIModel(this.AI_MODELS.prediction,s);return this.parsePredictionResponse(e)}catch(i){return this.generateBasicPredictions(e,t)}}async assessComplianceImpact(e,t){let i=`
    Assess compliance impact for findings:

    VULNERABILITIES: ${JSON.stringify(e)}
    BUSINESS CRITICAL: ${t.businessCritical}
    ENVIRONMENT: ${t.environment}

    Analyze impact on:
    - PCI DSS
    - SOX
    - GDPR/CCPA
    - ISO 27001
    - NIST Framework
    - Industry-specific regulations

    Provide specific compliance violations and requirements.
    `;try{let e=await this.callAIModel(this.AI_MODELS.risk_assessment,i);return this.parseComplianceResponse(e)}catch(t){return this.generateBasicComplianceAssessment(e)}}parseReasoningResponse(e){try{let t=JSON.parse(e);return{steps:t.reasoning_steps||[],confidence:t.confidence||75}}catch{return{steps:e.split("\n").filter(e=>e.includes(".")).slice(0,5),confidence:70}}}parseRiskResponse(e){try{let t=JSON.parse(e);return{totalScore:t.total_score||50,factors:t.risk_factors||this.getDefaultRiskFactors()}}catch{return{totalScore:50,factors:this.getDefaultRiskFactors()}}}parseCorrelationResponse(e,t){try{let t=JSON.parse(e);if(t.prioritized_findings)return t.prioritized_findings}catch{}return this.performBasicCorrelation(t)}parseRemediationResponse(e){try{return JSON.parse(e).remediation_steps||this.getDefaultRemediationSteps()}catch{return this.getDefaultRemediationSteps()}}parsePredictionResponse(e){try{return JSON.parse(e).predictions||[]}catch{return e.split("\n").filter(e=>e.trim().length>0).slice(0,5)}}parseComplianceResponse(e){try{return JSON.parse(e).compliance_impacts||[]}catch{return e.split("\n").filter(e=>e.includes("compliance")||e.includes("regulation")).slice(0,3)}}calculateFallbackRiskScore(e,t){let i=this.calculateSeverityScore(e);return{totalScore:Math.min(100,i+(t.businessCritical?20:10)+("internet"===t.exposureLevel?30:"internal"===t.exposureLevel?15:5)),factors:this.getDefaultRiskFactors()}}performBasicCorrelation(e){return e.sort((e,t)=>{let i={critical:4,high:3,medium:2,low:1};return i[t.severity]-i[e.severity]})}generateBasicRemediation(e){return e.map(e=>({priority:"critical"===e.severity?"immediate":"high"===e.severity?"high":"medium"===e.severity?"medium":"low",action:`Address ${e.title}`,description:e.recommendation||"Follow security best practices",estimatedTime:"critical"===e.severity?"24 hours":"1-2 weeks",riskReduction:"critical"===e.severity?40:"high"===e.severity?25:15}))}generateBasicPredictions(e,t){let i=[];return e.some(e=>e.title.includes("SQL"))&&i.push("Additional database vulnerabilities likely present"),e.some(e=>e.title.includes("XSS"))&&i.push("Input validation issues may exist elsewhere"),"internet"===t.exposureLevel&&i.push("Consider comprehensive external attack surface assessment"),i}generateBasicComplianceAssessment(e){let t=[];return e.some(e=>"critical"===e.severity)&&t.push("Critical vulnerabilities may violate PCI DSS requirements"),e.some(e=>e.title.includes("SSL")||e.title.includes("TLS"))&&t.push("Encryption issues impact GDPR and data protection compliance"),t}calculateThreatLevel(e){return e>=80?"critical":e>=60?"high":e>=40?"medium":"low"}calculateSeverityScore(e){let t={critical:40,high:25,medium:10,low:5};return e.reduce((e,i)=>e+(t[i.severity]||0),0)}getDefaultRiskFactors(){return{severity:50,exploitability:40,businessImpact:30,dataExposure:35,compliance:25,patchAvailability:60}}getDefaultRemediationSteps(){return[{priority:"high",action:"Review and address identified vulnerabilities",description:"Implement security patches and configuration changes",estimatedTime:"1-2 weeks",riskReduction:70}]}async analyzeContext(e,t){return{target_type:this.inferTargetType(e.target),service_fingerprint:this.extractServices(t),attack_surface:e.exposureLevel,business_context:e.businessCritical}}inferTargetType(e){return e.includes(".com")||e.includes(".org")?"web_application":e.match(/^\d+\.\d+\.\d+\.\d+$/)?"ip_address":"unknown"}extractServices(e){let t=[];for(let i of e)i.includes("http")&&t.push("HTTP"),(i.includes("ssl")||i.includes("https"))&&t.push("HTTPS"),i.includes("ssh")&&t.push("SSH"),i.includes("ftp")&&t.push("FTP");return[...new Set(t)]}async callAIModel(e,t){let{mcpRouter:s}=await i.e(630).then(i.bind(i,65630));return await s.getAnalysis(t,e)}constructor(){this.AI_MODELS={reasoning:"gpt-4",risk_assessment:"claude-3-sonnet",remediation:"deepseek-coder",prediction:"gpt-4-mini"}}}let d=new l;async function u(e){try{let t,i=await (0,c.HW)();if(!i)return o.NextResponse.json({error:"Authentication required"},{status:401});let{scanId:s,context:a,analysisType:n="full"}=await e.json();if(!s)return o.NextResponse.json({error:"Scan ID is required"},{status:400});let r=await (0,c.getScanById)(s);if(!r)return o.NextResponse.json({error:"Scan not found"},{status:404});if(r.user_id!==i.id)return o.NextResponse.json({error:"Access denied"},{status:403});let l=(await (0,c.getScanLogs)(s)).map(e=>e.message),u={target:r.target,scanType:r.tool_used||"unknown",environment:a?.environment||"unknown",businessCritical:a?.businessCritical||!1,exposureLevel:a?.exposureLevel||"internal"},p=[{id:"1",title:"SQL Injection Vulnerability",description:"User input is not properly sanitized, allowing SQL injection attacks",severity:"high",cve_refs:["CVE-2023-12345"],cwe_refs:["CWE-89"],recommendation:"Use parameterized queries and input validation",evidence:'Parameter "id" vulnerable to SQL injection',affected_urls:[`${r.target}/login.php`]},{id:"2",title:"Cross-Site Scripting (XSS)",description:"Reflected XSS vulnerability in search parameter",severity:"medium",cve_refs:[],cwe_refs:["CWE-79"],recommendation:"Implement output encoding and CSP headers",evidence:"Search parameter reflects unescaped user input",affected_urls:[`${r.target}/search.php`]},{id:"3",title:"Weak SSL/TLS Configuration",description:"Server supports deprecated SSL protocols and weak ciphers",severity:"medium",cve_refs:[],cwe_refs:["CWE-326"],recommendation:"Update SSL/TLS configuration to use TLS 1.2+ only",evidence:"SSL 3.0 and TLS 1.0 enabled with weak cipher suites",affected_urls:[r.target]}];switch(n){case"full":t=await d.analyzeVulnerabilities(p,u,l);break;case"risk_only":t={riskScore:(t=await d.analyzeVulnerabilities(p,u,l)).riskScore,threatLevel:t.threatLevel,reasoning:t.reasoning};break;case"remediation_only":t={remediationPlan:(t=await d.analyzeVulnerabilities(p,u,l)).remediationPlan,correlatedFindings:t.correlatedFindings};break;case"predictive_only":t={predictiveInsights:(t=await d.analyzeVulnerabilities(p,u,l)).predictiveInsights,complianceImpact:t.complianceImpact};break;default:return o.NextResponse.json({error:"Invalid analysis type"},{status:400})}return console.log(`AI analysis completed for scan ${s} by user ${i.id}`),o.NextResponse.json({success:!0,scanId:s,analysisType:n,context:u,findings:p,aiAnalysis:t,timestamp:new Date().toISOString(),message:"AI vulnerability analysis completed successfully"})}catch(e){return console.error("AI Analysis API error:",e),o.NextResponse.json({error:"AI analysis failed",details:e.message},{status:500})}}async function p(e){try{if(!await (0,c.HW)())return o.NextResponse.json({error:"Authentication required"},{status:401});switch(new URL(e.url).searchParams.get("action")){case"capabilities":return o.NextResponse.json({features:{multiStepReasoning:{name:"Multi-step Reasoning Engine",description:"Advanced logical analysis of vulnerability chains and attack paths",models:["gpt-4","claude-3-sonnet"],status:"available"},riskAssessment:{name:"AI-powered Risk Assessment",description:"Contextual risk scoring with business impact analysis",models:["claude-3-sonnet","gpt-4"],status:"available"},intelligentRemediation:{name:"Automated Remediation Planning",description:"Priority-based action plans with dependency mapping",models:["deepseek-coder","gpt-4"],status:"available"},predictiveAnalysis:{name:"Predictive Vulnerability Discovery",description:"ML-based prediction of additional vulnerabilities",models:["gpt-4-mini"],status:"available"},complianceMapping:{name:"Compliance Impact Assessment",description:"Automated mapping to regulatory frameworks",models:["claude-3-sonnet"],status:"available"}},analysisTypes:[{type:"full",name:"Complete AI Analysis",description:"Full multi-step analysis with all AI features",estimatedTime:"2-3 minutes"},{type:"risk_only",name:"Risk Assessment Only",description:"Focus on risk scoring and threat level assessment",estimatedTime:"30-60 seconds"},{type:"remediation_only",name:"Remediation Planning",description:"Generate intelligent remediation action plans",estimatedTime:"60-90 seconds"},{type:"predictive_only",name:"Predictive Insights",description:"Discover potential additional vulnerabilities",estimatedTime:"60-90 seconds"}],models:{"gpt-4":{status:"available",capabilities:["reasoning","risk_assessment"]},"claude-3-sonnet":{status:"available",capabilities:["risk_assessment","compliance"]},"deepseek-coder":{status:"available",capabilities:["remediation","technical_analysis"]},"gpt-4-mini":{status:"available",capabilities:["prediction","quick_analysis"]}}});case"model_status":return o.NextResponse.json({models:{"gpt-4":{status:"available",latency:"2.3s",success_rate:"98.5%"},"claude-3-sonnet":{status:"available",latency:"1.8s",success_rate:"99.1%"},"deepseek-coder":{status:"available",latency:"1.5s",success_rate:"97.8%"},"gpt-4-mini":{status:"available",latency:"0.8s",success_rate:"99.3%"}},overall_status:"operational",last_updated:new Date().toISOString()});default:return o.NextResponse.json({message:"Advanced AI Analysis API",description:"Multi-step reasoning engine for intelligent vulnerability analysis",endpoints:{"POST /api/ai-analysis":"Perform AI vulnerability analysis","GET /api/ai-analysis?action=capabilities":"Get AI capabilities","GET /api/ai-analysis?action=model_status":"Check model status"},version:"2.0.0"})}}catch(e){return console.error("AI Analysis GET error:",e),o.NextResponse.json({error:"Failed to retrieve AI analysis information",details:e.message},{status:500})}}let m=new a.AppRouteRouteModule({definition:{kind:n.RouteKind.APP_ROUTE,page:"/api/ai-analysis/route",pathname:"/api/ai-analysis",filename:"route",bundlePath:"app/api/ai-analysis/route"},resolvedPagePath:"/home/project/pentriarch-ai/src/app/api/ai-analysis/route.ts",nextConfigOutput:"",userland:s}),{workAsyncStorage:g,workUnitAsyncStorage:y,serverHooks:h}=m;function S(){return(0,r.patchFetch)({workAsyncStorage:g,workUnitAsyncStorage:y})}},27910:e=>{"use strict";e.exports=require("stream")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},34631:e=>{"use strict";e.exports=require("tls")},39727:()=>{},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},47990:()=>{},51906:e=>{function t(e){var t=Error("Cannot find module '"+e+"'");throw t.code="MODULE_NOT_FOUND",t}t.keys=()=>[],t.resolve=t,t.id=51906,e.exports=t},55511:e=>{"use strict";e.exports=require("crypto")},55591:e=>{"use strict";e.exports=require("https")},56621:(e,t,i)=>{"use strict";i.d(t,{HW:()=>r,Ji:()=>o,LT:()=>S,M:()=>d,Ss:()=>y,UI:()=>g,bA:()=>h,getScanById:()=>l,getScanLogs:()=>m,lJ:()=>c,oT:()=>u,supabase:()=>s,to:()=>p});let s=(0,i(39398).createClient)("https://demo.supabase.co","demo-anon-key-placeholder"),a=()=>({id:"demo-user-123",email:"demo@pentriarch.ai",name:"Demo User",created_at:new Date().toISOString(),role:"user"}),n=()=>[{id:"scan-1",user_id:"demo-user-123",target:"example.com",prompt:"Scan for common vulnerabilities",status:"completed",ai_model:"gpt-4",tool_used:"nmap",command_executed:"nmap -sV example.com",start_time:new Date(Date.now()-3e5).toISOString(),end_time:new Date(Date.now()-24e4).toISOString(),created_at:new Date(Date.now()-3e5).toISOString(),updated_at:new Date(Date.now()-24e4).toISOString(),metadata:{risk_assessment:"low"}},{id:"scan-2",user_id:"demo-user-123",target:"testsite.com",prompt:"Check for SQL injection vulnerabilities",status:"running",ai_model:"claude-3-sonnet",tool_used:"sqlmap",command_executed:"sqlmap -u testsite.com --batch",start_time:new Date(Date.now()-12e4).toISOString(),created_at:new Date(Date.now()-12e4).toISOString(),updated_at:new Date(Date.now()-6e4).toISOString(),metadata:{risk_assessment:"high"}}],r=async()=>a(),o=async e=>{{let t={...e,id:`demo-scan-${Date.now()}`,created_at:new Date().toISOString(),updated_at:new Date().toISOString()};return console.log("Demo mode: scan created",t),t}},c=async(e,t,i)=>{{let s={id:e,status:t,updated_at:new Date().toISOString(),end_time:"completed"===t||"failed"===t?new Date().toISOString():void 0,metadata:i};return console.log("Demo mode: scan updated",s),s}},l=async e=>{{let t=n();return t.find(t=>t.id===e)||t[0]}},d=async e=>{{let t={...e,id:`demo-report-${Date.now()}`,generated_at:new Date().toISOString()};return console.log("Demo mode: report created",t),t}},u=async e=>({id:"demo-report-1",scan_id:e,findings:[],summary:"Demo scan completed successfully",risk_score:3,generated_at:new Date().toISOString()}),p=async e=>{{let t={...e,id:`demo-log-${Date.now()}`};return console.log("Demo mode: log created",t),t}},m=async e=>[{id:"demo-log-1",scan_id:e,timestamp:new Date().toISOString(),level:"info",message:"Scan started",raw_output:"Starting Nmap scan..."},{id:"demo-log-2",scan_id:e,timestamp:new Date().toISOString(),level:"info",message:"Scan completed",raw_output:"Nmap scan completed successfully"}],g=async e=>{{let t={...e,id:`demo-notification-${Date.now()}`,created_at:new Date().toISOString()};return console.log("Demo mode: notification created",t),t}},y=async e=>[],h=async e=>(console.log("Demo mode: notification marked as read",e),{id:e,read:!0}),S=async(e,t,i,s,a)=>p({scan_id:e,timestamp:new Date().toISOString(),level:i,message:s,raw_output:a})},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},74075:e=>{"use strict";e.exports=require("zlib")},78335:()=>{},79428:e=>{"use strict";e.exports=require("buffer")},79551:e=>{"use strict";e.exports=require("url")},81630:e=>{"use strict";e.exports=require("http")},91645:e=>{"use strict";e.exports=require("net")},94735:e=>{"use strict";e.exports=require("events")},96487:()=>{}};var t=require("../../../webpack-runtime.js");t.C(e);var i=e=>t(t.s=e),s=t.X(0,[719,580,398],()=>i(23007));module.exports=s})();