(()=>{var e={};e.id=507,e.ids=[507],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},11997:e=>{"use strict";e.exports=require("punycode")},27910:e=>{"use strict";e.exports=require("stream")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},34631:e=>{"use strict";e.exports=require("tls")},39727:()=>{},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},47990:()=>{},51906:e=>{function t(e){var t=Error("Cannot find module '"+e+"'");throw t.code="MODULE_NOT_FOUND",t}t.keys=()=>[],t.resolve=t,t.id=51906,e.exports=t},55511:e=>{"use strict";e.exports=require("crypto")},55591:e=>{"use strict";e.exports=require("https")},56621:(e,t,r)=>{"use strict";r.d(t,{HW:()=>s,Ji:()=>i,LT:()=>_,M:()=>p,Ss:()=>f,UI:()=>g,bA:()=>S,getScanById:()=>c,getScanLogs:()=>u,lJ:()=>d,oT:()=>m,supabase:()=>n,to:()=>l});let n=(0,r(39398).createClient)("https://demo.supabase.co","demo-anon-key-placeholder"),o=()=>({id:"demo-user-123",email:"demo@pentriarch.ai",name:"Demo User",created_at:new Date().toISOString(),role:"user"}),a=()=>[{id:"scan-1",user_id:"demo-user-123",target:"example.com",prompt:"Scan for common vulnerabilities",status:"completed",ai_model:"gpt-4",tool_used:"nmap",command_executed:"nmap -sV example.com",start_time:new Date(Date.now()-3e5).toISOString(),end_time:new Date(Date.now()-24e4).toISOString(),created_at:new Date(Date.now()-3e5).toISOString(),updated_at:new Date(Date.now()-24e4).toISOString(),metadata:{risk_assessment:"low"}},{id:"scan-2",user_id:"demo-user-123",target:"testsite.com",prompt:"Check for SQL injection vulnerabilities",status:"running",ai_model:"claude-3-sonnet",tool_used:"sqlmap",command_executed:"sqlmap -u testsite.com --batch",start_time:new Date(Date.now()-12e4).toISOString(),created_at:new Date(Date.now()-12e4).toISOString(),updated_at:new Date(Date.now()-6e4).toISOString(),metadata:{risk_assessment:"high"}}],s=async()=>o(),i=async e=>{{let t={...e,id:`demo-scan-${Date.now()}`,created_at:new Date().toISOString(),updated_at:new Date().toISOString()};return console.log("Demo mode: scan created",t),t}},d=async(e,t,r)=>{{let n={id:e,status:t,updated_at:new Date().toISOString(),end_time:"completed"===t||"failed"===t?new Date().toISOString():void 0,metadata:r};return console.log("Demo mode: scan updated",n),n}},c=async e=>{{let t=a();return t.find(t=>t.id===e)||t[0]}},p=async e=>{{let t={...e,id:`demo-report-${Date.now()}`,generated_at:new Date().toISOString()};return console.log("Demo mode: report created",t),t}},m=async e=>({id:"demo-report-1",scan_id:e,findings:[],summary:"Demo scan completed successfully",risk_score:3,generated_at:new Date().toISOString()}),l=async e=>{{let t={...e,id:`demo-log-${Date.now()}`};return console.log("Demo mode: log created",t),t}},u=async e=>[{id:"demo-log-1",scan_id:e,timestamp:new Date().toISOString(),level:"info",message:"Scan started",raw_output:"Starting Nmap scan..."},{id:"demo-log-2",scan_id:e,timestamp:new Date().toISOString(),level:"info",message:"Scan completed",raw_output:"Nmap scan completed successfully"}],g=async e=>{{let t={...e,id:`demo-notification-${Date.now()}`,created_at:new Date().toISOString()};return console.log("Demo mode: notification created",t),t}},f=async e=>[],S=async e=>(console.log("Demo mode: notification marked as read",e),{id:e,read:!0}),_=async(e,t,r,n,o)=>l({scan_id:e,timestamp:new Date().toISOString(),level:r,message:n,raw_output:o})},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},74075:e=>{"use strict";e.exports=require("zlib")},78335:()=>{},79428:e=>{"use strict";e.exports=require("buffer")},79551:e=>{"use strict";e.exports=require("url")},81630:e=>{"use strict";e.exports=require("http")},91645:e=>{"use strict";e.exports=require("net")},94735:e=>{"use strict";e.exports=require("events")},96487:()=>{},99179:(e,t,r)=>{"use strict";r.r(t),r.d(t,{patchFetch:()=>f,routeModule:()=>m,serverHooks:()=>g,workAsyncStorage:()=>l,workUnitAsyncStorage:()=>u});var n={};r.r(n),r.d(n,{POST:()=>c});var o=r(96559),a=r(48088),s=r(37719),i=r(32190),d=r(56621);async function c(e){try{let t=await (0,d.HW)();if(!t)return i.NextResponse.json({error:"Unauthorized"},{status:401});let{scanId:n,format:o="pdf",includeRawOutput:a=!1}=await e.json();if(!n)return i.NextResponse.json({error:"Scan ID is required"},{status:400});if(!["pdf","json","xml","csv"].includes(o))return i.NextResponse.json({error:"Invalid format. Supported: pdf, json, xml, csv"},{status:400});let s=await getScanById(n);if(s.user_id!==t.id)return i.NextResponse.json({error:"Forbidden"},{status:403});let c=await (0,d.oT)(n);if(!c)return i.NextResponse.json({error:"Report not found. Generate report first."},{status:404});let m=[];if(a){let{getScanLogs:e}=await Promise.resolve().then(r.bind(r,56621));m=await e(n)}let l={scan:{id:s.id,target:s.target,tool_used:s.tool_used,start_time:s.start_time,end_time:s.end_time,status:s.status,ai_model:s.ai_model},report:{id:c.id,summary:c.summary,risk_score:c.risk_score,findings:c.findings,recommendations:c.recommendations,generated_at:c.generated_at},...a&&{logs:m},metadata:{exported_at:new Date().toISOString(),exported_by:t.email,format:o,platform:"Pentriarch AI"}};switch(o){case"json":return i.NextResponse.json(l,{headers:{"Content-Disposition":`attachment; filename="pentriarch-report-${n}.json"`,"Content-Type":"application/json"}});case"xml":{let e=function(e){let t=e=>e?.replace(/[<>&'"]/g,e=>({"<":"&lt;",">":"&gt;","&":"&amp;","'":"&apos;",'"':"&quot;"})[e]||e)||"";return`<?xml version="1.0" encoding="UTF-8"?>
<PentestReport>
  <Scan>
    <ID>${e.scan.id}</ID>
    <Target>${t(e.scan.target)}</Target>
    <Tool>${t(e.scan.tool_used||"")}</Tool>
    <StartTime>${e.scan.start_time}</StartTime>
    <EndTime>${e.scan.end_time||""}</EndTime>
    <Status>${t(e.scan.status)}</Status>
    <AIModel>${t(e.scan.ai_model||"")}</AIModel>
  </Scan>
  <Report>
    <ID>${e.report.id}</ID>
    <GeneratedAt>${e.report.generated_at}</GeneratedAt>
    <Findings>
      ${e.report.findings.map(e=>`
      <Finding>
        <Title>${t(e.title||"")}</Title>
        <Description>${t(e.description||"")}</Description>
        <Severity>${t(e.severity||"medium")}</Severity>
        <Impact>${t(e.impact||"")}</Impact>
        <Recommendation>${t(e.recommendation||"")}</Recommendation>
        <AffectedComponents>
          ${e.affected_components?.map(e=>`<Component>${t(e)}</Component>`).join("")||""}
        </AffectedComponents>
      </Finding>
      `).join("")}
    </Findings>
    <Summary>${t(e.report.summary||"")}</Summary>
  </Report>
</PentestReport>`}(l);return new i.NextResponse(e,{headers:{"Content-Disposition":`attachment; filename="pentriarch-report-${n}.xml"`,"Content-Type":"application/xml"}})}case"csv":{let e=function(e){let t=e=>`"${e?.replace(/"/g,'""')||""}"`,r="Section,Field,Value\n";return r+=`Scan,ID,${t(e.scan.id)}
Scan,Target,${t(e.scan.target)}
Scan,Tool,${t(e.scan.tool_used||"")}
Scan,Start Time,${t(e.scan.start_time)}
Scan,End Time,${t(e.scan.end_time||"")}
Scan,Status,${t(e.scan.status)}
Scan,AI Model,${t(e.scan.ai_model||"")}
`,e.report.findings.forEach((e,n)=>{r+=`Finding ${n+1},Title,${t(e.title||"")}
Finding ${n+1},Description,${t(e.description||"")}
Finding ${n+1},Severity,${t(e.severity||"medium")}
Finding ${n+1},Impact,${t(e.impact||"")}
Finding ${n+1},Recommendation,${t(e.recommendation||"")}
Finding ${n+1},Affected Components,${t(e.affected_components?.join(", ")||"")}
`}),r}(l);return new i.NextResponse(e,{headers:{"Content-Disposition":`attachment; filename="pentriarch-report-${n}.csv"`,"Content-Type":"text/csv"}})}case"pdf":{let e=await p(l);return new i.NextResponse(e,{headers:{"Content-Disposition":`attachment; filename="pentriarch-report-${n}.pdf"`,"Content-Type":"application/pdf"}})}default:return i.NextResponse.json({error:"Unsupported format"},{status:400})}}catch(e){return console.error("Export report error:",e),i.NextResponse.json({error:"Failed to export report",details:e.message},{status:500})}}async function p(e){let t=`
    <!DOCTYPE html>
    <html>
    <head>
      <title>Penetration Test Report</title>
      <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        .header { border-bottom: 2px solid #333; padding-bottom: 20px; }
        .finding { margin: 20px 0; padding: 15px; border-left: 4px solid #007cba; }
        .finding.high { border-left-color: #d32f2f; }
        .finding.critical { border-left-color: #b71c1c; }
        .finding.medium { border-left-color: #f57c00; }
        .finding.low { border-left-color: #388e3c; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
      </style>
    </head>
    <body>
      <div class="header">
        <h1>Penetration Test Report</h1>
        <p>Generated: ${e.report.generated_at}</p>
      </div>

      <h2>Scan Information</h2>
      <table>
        <tr><td>Target</td><td>${e.scan.target}</td></tr>
        <tr><td>Tool Used</td><td>${e.scan.tool_used||"N/A"}</td></tr>
        <tr><td>Scan Duration</td><td>${e.scan.end_time?`${Math.round((new Date(e.scan.end_time).getTime()-new Date(e.scan.start_time).getTime())/1e3)}s`:"N/A"}</td></tr>
        <tr><td>AI Model</td><td>${e.scan.ai_model||"N/A"}</td></tr>
        <tr><td>Status</td><td>${e.scan.status}</td></tr>
      </table>

    <h2>Security Findings</h2>
    ${0===e.report.findings.length?"<p>No security findings detected.</p>":e.report.findings.map(e=>`
        <div class="finding ${e.severity||"medium"}">
          <h3>${e.title||"Security Finding"}</h3>
          <p><strong>Severity:</strong> ${e.severity||"Medium"}</p>
          <p><strong>Description:</strong> ${e.description||"No description available"}</p>
          <p><strong>Impact:</strong> ${e.impact||"Impact assessment pending"}</p>
          <p><strong>Recommendation:</strong> ${e.recommendation||"Recommendations pending"}</p>
          ${e.affected_components?.length?`<p><strong>Affected Components:</strong> ${e.affected_components.join(", ")}</p>`:""}
        </div>
      `).join("")}
    </body>
    </html>
  `;return Buffer.from(t,"utf-8")}let m=new o.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/api/export-report/route",pathname:"/api/export-report",filename:"route",bundlePath:"app/api/export-report/route"},resolvedPagePath:"/home/project/pentriarch-ai/src/app/api/export-report/route.ts",nextConfigOutput:"",userland:n}),{workAsyncStorage:l,workUnitAsyncStorage:u,serverHooks:g}=m;function f(){return(0,s.patchFetch)({workAsyncStorage:l,workUnitAsyncStorage:u})}}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),n=t.X(0,[719,580,398],()=>r(99179));module.exports=n})();